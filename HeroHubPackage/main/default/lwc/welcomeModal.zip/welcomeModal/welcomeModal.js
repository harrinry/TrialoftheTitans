import { LightningElement, track, api, wire } from "lwc";
import getViewedWeekly from "@salesforce/apex/modalHelper.getViewedWeekly";
import getViewedWelcome from "@salesforce/apex/modalHelper.getViewedWelcome";
import closeNewsModal from "@salesforce/apex/modalHelper.closeNewsModal";
import closeWelcomeModal from "@salesforce/apex/modalHelper.closeWelcomeModal";
import Id from '@salesforce/user/Id';
import {ShowToastEvent} from 'lightning/platformShowToastEvent'


export default class WelcomeModal extends LightningElement {
  @api hasViewedNews;
  @api hasViewedWelcome;

  //Squad Name of User w/ Top 3 Heroes in that squad
  //Team Name of User and top 3 teams w/ scores
  //How many weeks the team has been on top in the last 3 months.

  connectedCallback(){ 
    console.log(Id);
    console.log("connected is called");
    
    getViewedWeekly(Id)
    .then(result => {this.hasViewedNews = result;
      console.log(result);
    })
    .catch(error => console.log(result));

  console.log("after viewed weekly call");

    getViewedWelcome(Id)
    .then(result => {this.hasViewedWelcome = result;
      console.log(result);
    })
    .catch(error => console.log(result));
    console.log("after viewed welcome call");

  }

  closeWelcome() {
    console.log('closeWelcome Called');
    this.hasViewedWelcome = true;
    console.log('var changed');
    closeWelcomeModal(Id);
    console.log('closeWelcomeModal Apex Called');
  }

  closeNews(){
    console.log('closeNews Called');
    this.hasViewedNews = true;
    console.log('var changed');
    closeNewsModal(Id);
    console.log('closeNewsModal Apex Called');
  }
}
